package de.juliusschneider.auction;

/**
 * Schnittstelle fuer spaetere Payment-/Economy-Anbindungen.
 * Ein Provider meldet Gebote ausschliesslich ueber
 * {@link JuliusschneiderAuctionManager#submitBid(String, long, String)}.
 * Diese Version enthaelt bewusst KEINE serverabhaengige Zahlungserkennung.
 */
public interface JuliusschneiderBidProvider {
    String id();
    default void onAuctionStarted(JuliusschneiderAuctionManager manager) {}
    default void onAuctionEnded(JuliusschneiderAuctionManager manager) {}
}
