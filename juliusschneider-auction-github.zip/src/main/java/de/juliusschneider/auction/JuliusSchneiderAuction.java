package de.juliusschneider.auction;

import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Konstanten und Logging der Mod. */
public final class JuliusSchneiderAuction {
    public static final String MOD_ID = "juliusschneider_auction";
    public static final String DISPLAY_NAME = "JuliusSchneider Auction";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private JuliusSchneiderAuction() {}

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    /** Debug-Log nur in die Log-Datei, nie in den Spielerchat. */
    public static void debug(String msg) {
        if (JuliusschneiderAuctionConfig.get().debugLogging) LOGGER.info("[debug] {}", msg);
    }
}
