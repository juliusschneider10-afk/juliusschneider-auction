package de.juliusschneider.auction;

import com.mojang.blaze3d.platform.InputConstants;
import de.juliusschneider.auction.ui.JuliusschneiderAuctionScreen;
import de.juliusschneider.auction.ui.JuliusschneiderBaseScreen;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

public final class JuliusschneiderAuctionKeybinds {
    private static KeyMapping toggle;

    private JuliusschneiderAuctionKeybinds() {}

    public static void register() {
        KeyMapping.Category category = KeyMapping.Category.register(JuliusSchneiderAuction.id("main"));
        toggle = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key." + JuliusSchneiderAuction.MOD_ID + ".toggle", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_J, category));
    }

    /** Pro Tick aufrufen. Schliessen im geoeffneten Screen erfolgt per ESC. */
    public static void poll(Minecraft mc) {
        if (toggle == null) return;
        while (toggle.consumeClick()) {
            if (mc.screen instanceof JuliusschneiderBaseScreen) mc.setScreen(null);
            else if (mc.screen == null) mc.setScreen(new JuliusschneiderAuctionScreen());
        }
    }
}
