package de.juliusschneider.auction.ui;

import de.juliusschneider.auction.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;

import java.util.List;

import static de.juliusschneider.auction.ui.JuliusschneiderUi.*;

/** Offene Rueckzahlungen: jeder Klick auf ZAHLEN sendet genau einen /pay-Befehl. */
public class JuliusschneiderRefundScreen extends JuliusschneiderBaseScreen {
    private static final int ROWS = 7;
    private final Screen parent;
    private final JuliusschneiderAuctionManager m = JuliusschneiderAuctionManager.get();

    public JuliusschneiderRefundScreen(Screen parent) {
        super("JuliusSchneider Auction - Rueckzahlungen");
        this.parent = parent;
    }

    private String command(JuliusschneiderAuctionManager.Refund r) {
        String c = JuliusschneiderAuctionConfig.get().refundCommand
                .replace("%player%", r.player()).replace("%amount%", String.valueOf(r.amount())).trim();
        return c.startsWith("/") ? c.substring(1) : c;
    }

    @Override
    protected void build() {
        List<JuliusschneiderAuctionManager.Refund> list = m.pendingRefunds();
        for (int i = 0; i < Math.min(ROWS, list.size()); i++) {
            var r = list.get(i);
            btn(px + pw - 14 - 80, py + 48 + i * 28, 80, 22, "ZAHLEN", GREEN, () -> {
                var mc = Minecraft.getInstance();
                if (mc.player == null) { flash("Nicht im Spiel.", true); return; }
                mc.player.connection.sendCommand(command(r));
                m.markRefunded(r.player(), r.amount());
                flash("Rueckzahlung an " + r.player() + " gesendet", false);
                rebuildWidgets();
            });
        }
        btn(px + 14, py + ph - 46, pw - 28, 28, "ZURUECK", GOLD, this::onClose);
    }

    @Override
    protected void draw(GuiGraphicsExtractor g, int mx, int my) {
        textScaled(g, "RUECKZAHLUNGEN", px + 14, py + 12, GOLD, 1.3f);
        var list = m.pendingRefunds();
        if (list.isEmpty()) {
            centered(g, "Keine offenen Rueckzahlungen", px + pw / 2, py + 90, GREEN);
            return;
        }
        for (int i = 0; i < Math.min(ROWS, list.size()); i++) {
            var r = list.get(i);
            int y = py + 48 + i * 28;
            panel(g, px + 14, y, pw - 28 - 88, 22, PANEL, BORDER);
            text(g, trim(r.player(), 120), px + 22, y + 7, TEXT);
            text(g, trim("/" + command(r), 150), px + 150, y + 7, MUTED);
            textRight(g, money(r.amount()), px + pw - 14 - 96, y + 7, GOLD);
        }
        if (list.size() > ROWS) text(g, "+ " + (list.size() - ROWS) + " weitere", px + 14, py + 48 + ROWS * 28, MUTED);
    }

    @Override
    public void onClose() { Minecraft.getInstance().setScreen(parent); }
}
