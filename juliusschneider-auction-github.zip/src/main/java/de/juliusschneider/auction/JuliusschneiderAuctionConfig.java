package de.juliusschneider.auction;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Persistente Einstellungen: config/juliusschneider_auction.json */
public final class JuliusschneiderAuctionConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static JuliusschneiderAuctionConfig instance = new JuliusschneiderAuctionConfig();

    public String adTextIdle = "Live auf Twitch: Auktionen, Giveaways und mehr!";
    public String adTextAuction = "[itemname] Auktion von juliusschneider ist jetzt live!";
    public int adCooldownSeconds = 30;
    public boolean hudEnabled = true;
    public boolean warningSound = true;
    public boolean debugLogging = false;
    public String hudPosition = "TOP_RIGHT"; // TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT
    public float hudScale = 1.0f;
    public long lastMinBid = 500_000;
    public int lastDurationSeconds = 300;
    // Zahlungserkennung (Spieler zahlen per /pay an dich). Regex braucht die Gruppen (?<player>..) und (?<amount>..)
    public boolean paymentDetection = false;
    public String paymentRegex = "(?i)(?<player>\\w{3,16}) (?:sent you|hat dir|paid you|hat dir gesendet)[: ]*\\$?(?<amount>[\\d.,]+[kmb]?)";
    public String refundCommand = "pay %player% %amount%";

    public static final String[] POSITIONS = {"TOP_LEFT", "TOP_RIGHT", "BOTTOM_RIGHT", "BOTTOM_LEFT"};
    public static final float[] SCALES = {0.75f, 1.0f, 1.25f, 1.5f};

    public static JuliusschneiderAuctionConfig get() { return instance; }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("juliusschneider_auction.json");
    }

    public static void load() {
        try {
            if (Files.exists(path())) {
                var c = GSON.fromJson(Files.readString(path()), JuliusschneiderAuctionConfig.class);
                if (c != null) instance = c;
            }
        } catch (Exception e) {
            JuliusSchneiderAuction.LOGGER.error("Config konnte nicht geladen werden", e);
        }
        if (instance.adCooldownSeconds < 0) instance.adCooldownSeconds = 0;
        save();
    }

    public static void save() {
        try {
            Files.writeString(path(), GSON.toJson(instance));
        } catch (Exception e) {
            JuliusSchneiderAuction.LOGGER.error("Config konnte nicht gespeichert werden", e);
        }
    }

    public void cyclePosition() {
        for (int i = 0; i < POSITIONS.length; i++)
            if (POSITIONS[i].equals(hudPosition)) { hudPosition = POSITIONS[(i + 1) % POSITIONS.length]; return; }
        hudPosition = POSITIONS[0];
    }

    public void cycleScale() {
        for (int i = 0; i < SCALES.length; i++)
            if (Math.abs(SCALES[i] - hudScale) < 0.01f) { hudScale = SCALES[(i + 1) % SCALES.length]; return; }
        hudScale = 1.0f;
    }
}
