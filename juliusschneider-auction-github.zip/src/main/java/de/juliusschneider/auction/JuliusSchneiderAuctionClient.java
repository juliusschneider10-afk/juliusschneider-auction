package de.juliusschneider.auction;

import de.juliusschneider.auction.ui.JuliusschneiderAuctionHud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;

public class JuliusSchneiderAuctionClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        JuliusschneiderAuctionConfig.load();
        JuliusschneiderAuctionKeybinds.register();
        JuliusschneiderChatPaymentProvider.register();
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, ctx) -> JuliusschneiderAuctionCommands.register(dispatcher));
        var hud = new JuliusschneiderAuctionHud();
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, JuliusSchneiderAuction.id("hud"), hud::extract);
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            JuliusschneiderAuctionManager.get().tick();
            JuliusschneiderAuctionKeybinds.poll(mc);
        });
        JuliusSchneiderAuction.LOGGER.info("{} geladen", JuliusSchneiderAuction.DISPLAY_NAME);
    }
}
